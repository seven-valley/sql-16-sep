# :cocktail: TP 01 VIP Cocktail
Créer une base de donnée : **invitation**  
Créer une table : **personne**  
Rajouter le prefixe "inv" à votre table  
  
Nou allons créer une liste d'invités pour des soirées VIP  
![brad](../img/03/brad.webp)
![george](../img/03/george.webp)
![jean](../img/03/jean.webp)
  
Chaque personne à :
  
- un prénom
- un nom  
- un age  
- la date de sont inscription
- un status : Valide ou NON Valide (un booléen)
- un type : membre ou non membre (une énumération)
- une description
- salaire annuel

Créer un fichier SQL
- on efface la base si elle existe
- avec création de la base
- tester votre fichier en l'important dans PhpMyadmin




