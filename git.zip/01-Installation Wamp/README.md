# Installation du Serveur Wamp
## PHP et MySQL
https://www.wampserver.com/fr/

## 1 Téléchager :
![Wamp](/img/wamp-download.webp)

## 2 Cliquez sur le lien pour éviter de remplir votre nom :
![download](/img/download.webp)


## 3 **Si vous avez un problème** de dll :
https://wampserver.aviatechno.net/

-1 : Télécharger les 4 exe  
-2 : Si besoin télécharger les 4 autres

![aviato](/img/aviato.webp)


## 4 nettoyage !
Après l'installation néttoyer le repertoire **www** :  
Ne garder que l'icone !

```
c:\wamp64\www
```

```
C:\  
│
└─── wamp64
│   │
│   └─── www
│       │   favicon.ico
│   
```


